<?php
/**
 * @file
 * SoundManager 2 Inline Player
 */
?>
<ul class="graphic">
  <?php foreach ($tracks as $track): ?>
    <li><?php print $track; ?></li>
  <?php endforeach; ?>
</ul>